//
//  bmiViewController.swift
//  BMI Calculator
//
//  Created by Andika Leonardo on 05/09/18.
//  Copyright © 2018 Andika Leonardo. All rights reserved.
//

import UIKit

class bmiViewController: UIViewController {


    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var bmiValue: UILabel!
    @IBOutlet weak var heightvalue1: UILabel!
    @IBOutlet weak var heightslider: UISlider!

    
    @IBAction func height(_ sender: Any) {
        heightvalue1.text = String(heightslider.value)
        bmiValue.text = String(bmiCalculator(w: weightslider.value, h: heightslider.value))
        
    }
    

    @IBOutlet weak var weightvalue: UILabel!
    @IBOutlet weak var weightslider: UISlider!
    @IBAction func weight(_ sender: UISlider) {
        
        weightvalue.text = String(weightslider.value)
        bmiValue.text = String(bmiCalculator(w: weightslider.value, h: heightslider.value))
    }
    
    func bmiCalculator (w: Float, h: Float) -> Float{
        
        var hInMeter = h / 100
        
        var value = (w / (hInMeter * hInMeter))
        
        if value <= 18.5{
            status.text = "Under Weight"
            image.image = UIImage(named: "skinny")
            
        }
        else if value <= 25{
            status.text = "Normal"
            image.image = UIImage(named: "normal-1")
        }
        else if value <= 30{
            status.text = "Overweight"
            image.image = UIImage(named: "fat")
        }
        else if value > 30{
            status.text = "Obese"
            image.image = UIImage(named: "obese-1")
        }
        
        return value
        
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()

        weightslider.maximumValue = 150
        weightslider.minimumValue = 0
        
        heightslider.maximumValue = 200
        heightslider.minimumValue = 0
        
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var outletSwitch: UISwitch!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
