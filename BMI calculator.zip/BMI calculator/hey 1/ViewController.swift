    //
//  ViewController.swift
//  hey 1
//
//  Created by Andika Leonardo on 05/09/18.
//  Copyright © 2018 Andika Leonardo All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func height(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

